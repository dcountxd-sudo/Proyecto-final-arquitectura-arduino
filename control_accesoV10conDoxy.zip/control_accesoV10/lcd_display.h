/**
 * @file lcd_display.h
 * @brief Control del LCD 16x2.
 */

#ifndef LCD_DISPLAY_H
#define LCD_DISPLAY_H

#include <Arduino.h>
#include <LiquidCrystal.h>
#include "pins.h"

extern LiquidCrystal lcd;

void lcd_init();
void lcd_estado(int estado);
void lcd_mensaje(const char* linea1, const char* linea2, unsigned long espera);
void lcd_clave(byte digitos);
void lcd_sensores_ambiental(float temp, int luz);
void lcd_sensores_intrusos(int hall, int mic);
void lcd_ingresar_hora();
void lcd_ingresar_clave();
void lcd_bienvenido(const char* nombre);
void lcd_puerta_cerrada(bool cambioActivo);
void lcd_nueva_clave();
void lcd_confirmar_clave();
void lcd_alarma(int contAlarmas);

#endif