/**
 * @file fsm.cpp
 * @brief Implementación de la máquina de estados.
 */

#include <Arduino.h>
#include "constants.h"
#include "fsm.h"
#include "actuators.h"
#include "sensors.h"
#include "lcd_display.h"
#include "keypad_handler.h"
#include "time_manager.h"
#include "eeprom.h"
#include "tasks.h"

static StateMachine fsm(6, 15);
Input inputFSM = INPUT_UNKNOWN;

// Variables de estado
static unsigned long tEntradaEstado = 0;
static unsigned long tPrimeraAlarma = 0;
static unsigned long tPuertaAbierta = 0;
static unsigned long tUltimoLCD = 0;
static bool puertaYaCerrada = false;
extern bool cambioClaveActivo = false;
byte cont_intentos = 0;
byte cont_alarmas = 0;
byte cont_mic = 0;
int usuario_actual = -1;
static State estadoAntesDeAlarma = MONITOR_AMBIENTAL;

// Variables para cambio de clave
char claveNueva1[NUM_DIGIT + 1];
char claveNueva2[NUM_DIGIT + 1];
byte idxNueva = 0;
byte faseClave = 0;

// Variables para ingreso de hora
static char bufHora[5];
extern byte idxHora = 0;

/**
 * @brief Autentica usuario (válida clave/franja, incrementa usos).
 * @param idx Índice del usuario
 */
static void autenticar(int idx) {
  Usuario u;
  leerUsuario(idx, u);
  
  if (horaConfigurada && !dentroFranja(u, horaActual)) {
    lcd_mensaje("Acceso denegado", "Fuera de franja", 1500);
    inputFSM = INPUT_RESET;
    return;
  }
  
  usuario_actual = idx;
  cont_intentos = 0;
  
  u.usos++;
  guardarUsuario(idx, u);
  cambioClaveActivo = (u.usos > MAX_USOS);
  
  inputFSM = INPUT_CLAVE_OK;
}

/**
 * @brief Acción al entrar a INICIO.
 */
static void entrarInicio() {
  Serial.println("-> INICIO");
  apagarTodo();
  servo_cerrar();
  usuario_actual = -1;
  cont_intentos = 0;
  idx_clave = 0;
  idxHora = 0;
  memset(clave_ingresada, 0, sizeof(clave_ingresada));
  tEntradaEstado = millis();
  
  if (!horaConfigurada) lcd_ingresar_hora();
  else lcd_ingresar_clave();
}

/**
 * @brief Acción al entrar a CONFIG (abre puerta 3s).
 */
static void entrarConfig() {
  Serial.println("-> CONFIG");
  tEntradaEstado = millis();
  tPuertaAbierta = millis();
  puertaYaCerrada = false;
  idxNueva = 0;
  faseClave = 0;
  
  setLED(false, true, false);
  servo_abrir();
  
  Usuario u;
  leerUsuario(usuario_actual, u);
  lcd_bienvenido(u.nombre);
}

/**
 * @brief Acción al entrar a MONITOR_AMBIENTAL.
 */
static void entrarMonitorAmbiental() {
  lcd.clear();
  Serial.println("ENTRO A AMBIENTAL");
  apagarTodo();
  tEntradaEstado = millis();
  leer_temperatura_inmediato();
  leer_luz_inmediato();
  lcd_estado(MONITOR_AMBIENTAL);
  lcd_sensores_ambiental(tempLeida, luzLeida);
  sensors_start_ambient_tasks();
}

/**
 * @brief Acción al entrar a MONITOR_INTRUSOS.
 */
static void entrarMonitorIntrusos() {
  lcd.clear();
  Serial.println("ENTRO A INTRUSOS");
  apagarTodo();
  cont_mic = 0;
  tEntradaEstado = millis();
  leer_hall_inmediato();
  leer_microfono_inmediato();
  lcd_estado(MONITOR_INTRUSOS);
  lcd_sensores_intrusos(hallLeido, micLeido);
  sensors_start_intrusos_tasks();
}

/**
 * @brief Acción al entrar a ALARMA.
 */
static void entrarAlarma() {
  Serial.println("-> ALARMA");
  if (cont_alarmas == 0) tPrimeraAlarma = millis();
  cont_alarmas++;
  tEntradaEstado = millis();
  lcd.clear();
  lcd.print("!!! ALARMA !!!");
  lcd_alarma(cont_alarmas);
  buzzer_on();
}

/**
 * @brief Acción al entrar a BLOQUEO.
 */
static void entrarBloqueo() {
  Serial.println("-> BLOQUEO");
  tEntradaEstado = millis();
  lcd_estado(BLOQUEO);
  lcd.setCursor(0, 1);
  lcd.print("Pres. boton");
}

/**
 * @brief Acción al salir de CONFIG.
 */
static void salirConfig() {
  servo_cerrar();
  apagarTodo();
  cambioClaveActivo = false;
}

/**
 * @brief Acción al salir de MONITOR_AMBIENTAL.
 */
static void salirMonitorAmbiental() {
  estadoAntesDeAlarma = MONITOR_AMBIENTAL;
  sensors_stop_ambient_tasks();
}

/**
 * @brief Acción al salir de MONITOR_INTRUSOS.
 */
static void salirMonitorIntrusos() {
  estadoAntesDeAlarma = MONITOR_INTRUSOS;
  sensors_stop_intrusos_tasks();
}

/**
 * @brief Acción al salir de ALARMA.
 */
static void salirAlarma() {
  apagarTodo();
  buzzer_off();
}

/**
 * @brief Acción al salir de BLOQUEO.
 */
static void salirBloqueo() {
  apagarTodo();
  cont_intentos = 0;
}

/**
 * @brief Loop del estado INICIO (configura hora, lee clave/RFID).
 */
static void loopInicio() {
  if (!horaConfigurada) {
    char key = keypad_get_key();
    if (!key) return;
    if (key >= '0' && key <= '9' && idxHora < 4) {
      bufHora[idxHora++] = key;
      lcd.setCursor(6 + idxHora - 1, 1);
      lcd.print(key);
    } 
    else if (key == '#' && idxHora == 4) {
      bufHora[4] = '\0';
      byte h = (bufHora[0]-'0')*10 + (bufHora[1]-'0');
      byte m = (bufHora[2]-'0')*10 + (bufHora[3]-'0');
      if (time_validar(h, m)) {
        time_set_hora(h, m);
        lcd.clear(); lcd.print("Hora OK");
        TaskHoraOk.Start();
      } else {
        lcd.clear(); lcd.print("Hora invalida");
        TaskHoraInv.Start();
      }
    } 
    else if (key == '*') {
      idxHora = 0;
      lcd_ingresar_hora();
    }
    return;
  }

  char key = keypad_get_key();
  if (key == '*') {
    keypad_limpiar_buffer();
    lcd_ingresar_clave();
    return;
  }

  if (key >= '0' && key <= '9') {
    if (idx_clave < NUM_DIGIT) {
      clave_ingresada[idx_clave++] = key;
      lcd_clave(idx_clave);
    }
    if (idx_clave == NUM_DIGIT) {
      clave_ingresada[NUM_DIGIT] = '\0';
      int encontrado = buscarPorClave(clave_ingresada);
      keypad_limpiar_buffer();
      if (encontrado >= 0) {
        autenticar(encontrado);
      } else {
        cont_intentos++;
        lcd_mensaje("Clave incorrecta", "", 1000);
        if (cont_intentos >= NUM_INTENTOS) {
          setLED(true, false, false);
          inputFSM = INPUT_BLOQUEADO;
        } else {
          setLED(false, false, true);
          char buf[17];
          snprintf(buf, sizeof(buf), "Intentos: %d/%d", cont_intentos, NUM_INTENTOS);
          lcd_mensaje("Clave erronea", buf, 1200);
          setLED(false, false, false);
          lcd_ingresar_clave();
        }
      }
    }
    return;
  }

  byte uidLeido[MAX_UID];
  if (rfid_leer_uid(uidLeido) == 0) {
    int encontrado = buscarPorUID(uidLeido);
    if (encontrado >= 0) autenticar(encontrado);
    else { lcd_mensaje("Tarjeta invalida", "", 1000); lcd_ingresar_clave(); }
  }
}

/**
 * @brief Loop del estado CONFIG (cambio de clave, salida con D).
 */
static void loopConfig() {
  if (millis() - tEntradaEstado < T_BIENVENIDA) return;
  
  if (!puertaYaCerrada && millis() - tPuertaAbierta >= T_PUERTA_ABIERTA) {
    servo_cerrar();
    setLED(false, false, false);
    puertaYaCerrada = true;
    lcd_puerta_cerrada(cambioClaveActivo);
  }
  if (!puertaYaCerrada) return;

  char key = keypad_get_key();
  if (!key) return;

  if (key == 'D') { inputFSM = INPUT_TO_AMBIENTAL; return; }
  if (key == 'A' || cambioClaveActivo) {
    if (faseClave == 0) {
      cambioClaveActivo = true;
      idxNueva = 0;
      lcd_nueva_clave();
      faseClave = 1;
      return;
    }
  }

  if (faseClave == 1 && key >= '0' && key <= '9') {
    if (idxNueva < NUM_DIGIT) {
      claveNueva1[idxNueva++] = key;
      lcd.setCursor(idxNueva - 1, 1);
      lcd.print("*");
    }
    if (idxNueva == NUM_DIGIT) {
      claveNueva1[NUM_DIGIT] = '\0';
      idxNueva = 0;
      faseClave = 2;
      lcd_confirmar_clave();
    }
    return;
  }

  if (faseClave == 2 && key >= '0' && key <= '9') {
    if (idxNueva < NUM_DIGIT) {
      claveNueva2[idxNueva++] = key;
      lcd.setCursor(idxNueva - 1, 1);
      lcd.print("*");
    }
    if (idxNueva == NUM_DIGIT) {
      claveNueva2[NUM_DIGIT] = '\0';
      if (strcmp(claveNueva1, claveNueva2) != 0) {
        lcd_mensaje("No coinciden", "", 1000);
        faseClave = 1; idxNueva = 0; lcd_nueva_clave();
        return;
      }
      Usuario u;
      leerUsuario(usuario_actual, u);
      if (claveRepetida(u, claveNueva1)) {
        lcd_mensaje("Clave ya usada", "", 1000);
        faseClave = 1; idxNueva = 0; lcd_nueva_clave();
        return;
      }
      cambiarClave(usuario_actual, claveNueva1);
      lcd_mensaje("Clave cambiada!", "", 1200);
      cambioClaveActivo = false;
      faseClave = 0; idxNueva = 0;
      lcd_puerta_cerrada(false);
    }
    return;
  }
}

/**
 * @brief Loop de MONITOR_AMBIENTAL (temp/luz, timeout 5s).
 */
static void loopMonitorAmbiental() {
  sensors_update_tasks();
  unsigned long ahora = millis();
  unsigned long elapsed = ahora - tEntradaEstado;
  unsigned long restante = (T_MONITOR_AMB > elapsed) ? T_MONITOR_AMB - elapsed : 0;

  if (tempLeida < UMBRAL_TEMP_BAJO && luzLeida > UMBRAL_LUZ_BAJO) {
    inputFSM = INPUT_SENSOR_MAL;
    return;
  }

  if (ahora - tUltimoLCD >= 1000) {
    tUltimoLCD = ahora;
    lcd_estado(MONITOR_AMBIENTAL);
    lcd_sensores_ambiental(tempLeida, luzLeida);
    lcd.setCursor(14, 1);
    lcd.print(restante / 1000 + 1); lcd.print("s");
  }

  char key = keypad_get_key();
  if (key == '*' && usuario_actual >= 0) { inputFSM = INPUT_CLAVE_OK; return; }
  if (restante == 0) { inputFSM = INPUT_TO_INTRUSOS; }
}

/**
 * @brief Loop de MONITOR_INTRUSOS (Hall/mic, timeout 2s, intrusión).
 */
static void loopMonitorIntrusos() {
  sensors_update_tasks();
  char key = keypad_get_key();
  if (key == '#') { inputFSM = INPUT_CLAVE_OK; return; }

  unsigned long ahora = millis();
  unsigned long elapsed = ahora - tEntradaEstado;
  unsigned long restante = (T_MONITOR_INT > elapsed) ? T_MONITOR_INT - elapsed : 0;

  if (ahora - tUltimoLCD >= 1000) {
    tUltimoLCD = ahora;
    lcd_estado(MONITOR_INTRUSOS);
    lcd_sensores_intrusos(hallLeido, micLeido);
    lcd.setCursor(14, 1);
    lcd.print(restante / 1000 + 1); lcd.print("s");
  }

  static unsigned long ultimaCuenta = 0;
  if (hallLeido < UMBRAL_HALL && (micLeido < UMBRAL_MIC || micDig == HIGH)) {
    if (millis() - ultimaCuenta >= 500) {
      cont_mic++;
      ultimaCuenta = millis();
    }
    if (cont_mic >= UMBRAL_MIC_VECES) {
      cont_mic = 0;
      lcd_mensaje("INTRUSO!", "Hall+Mic activos", 500);
      inputFSM = INPUT_SENSOR_MAL;
      return;
    }
  }

  if (restante == 0) {
    cont_mic = 0;
    inputFSM = INPUT_TO_AMBIENTAL;
  }
}

/**
 * @brief Loop de ALARMA (parpadeo, retorno al monitor, 3 alarmas→INICIO).
 */
static void loopAlarma() {
  parpadeoRojo(T_ALARMA_ON, T_ALARMA_OFF);
  buzzer_on();

  unsigned long ahora = millis();
  unsigned long tEspera = (estadoAntesDeAlarma == MONITOR_AMBIENTAL) ? T_ALARMA_AMB : T_ALARMA_INT;
  unsigned long restante = (tEspera > (ahora - tEntradaEstado)) ? tEspera - (ahora - tEntradaEstado) : 0;

  if (ahora - tUltimoLCD >= 500) {
    tUltimoLCD = ahora;
    lcd_alarma(cont_alarmas);
    lcd.setCursor(14, 1);
    lcd.print(restante / 1000 + 1); lcd.print("s");
  }

  if (cont_alarmas >= 3 && (ahora - tPrimeraAlarma) < T_ALARMA_MAX) {
    lcd_mensaje("3 alarmas!", "-> INICIO", 800);
    cont_alarmas = 0;
    inputFSM = INPUT_RESET;
    return;
  }

  if (restante == 0) {
    if (estadoAntesDeAlarma == MONITOR_AMBIENTAL) inputFSM = INPUT_ALARMA_AMB;
    else inputFSM = INPUT_ALARMA_INT;
  }
}

/**
 * @brief Loop de BLOQUEO (led rojo, espera botón).
 */
static void loopBloqueo() {
  parpadeoRojo(T_BLOQUEO_ON, T_BLOQUEO_OFF);
  if (millis() - tUltimoLCD >= 600) {
    tUltimoLCD = millis();
    lcd.setCursor(0, 1);
    lcd.print("Pres. boton     ");
  }
}

/**
 * @brief Configura todas las transiciones y acciones de la FSM.
 */
void fsm_init() {
  fsm.AddTransition(INICIO, CONFIG, []() { return inputFSM == INPUT_CLAVE_OK; });
  fsm.AddTransition(INICIO, BLOQUEO, []() { return inputFSM == INPUT_BLOQUEADO; });
  fsm.AddTransition(INICIO, INICIO, []() { return inputFSM == INPUT_RESET; });
  fsm.AddTransition(CONFIG, MONITOR_AMBIENTAL, []() { return inputFSM == INPUT_TO_AMBIENTAL; });
  fsm.AddTransition(CONFIG, INICIO, []() { return inputFSM == INPUT_RESET; });
  fsm.AddTransition(MONITOR_AMBIENTAL, MONITOR_INTRUSOS, []() { return inputFSM == INPUT_TO_INTRUSOS; });
  fsm.AddTransition(MONITOR_AMBIENTAL, CONFIG, []() { return inputFSM == INPUT_CLAVE_OK; });
  fsm.AddTransition(MONITOR_AMBIENTAL, ALARMA, []() { return inputFSM == INPUT_SENSOR_MAL; });
  fsm.AddTransition(MONITOR_INTRUSOS, MONITOR_AMBIENTAL, []() { return inputFSM == INPUT_TO_AMBIENTAL; });
  fsm.AddTransition(MONITOR_INTRUSOS, CONFIG, []() { return inputFSM == INPUT_CLAVE_OK; });
  fsm.AddTransition(MONITOR_INTRUSOS, ALARMA, []() { return inputFSM == INPUT_SENSOR_MAL; });
  fsm.AddTransition(ALARMA, MONITOR_AMBIENTAL, []() { return inputFSM == INPUT_ALARMA_AMB; });
  fsm.AddTransition(ALARMA, MONITOR_INTRUSOS, []() { return inputFSM == INPUT_ALARMA_INT; });
  fsm.AddTransition(ALARMA, INICIO, []() { return inputFSM == INPUT_RESET; });
  fsm.AddTransition(BLOQUEO, INICIO, []() { return inputFSM == INPUT_RESET; });
  
  fsm.SetOnEntering(INICIO, entrarInicio);
  fsm.SetOnEntering(CONFIG, entrarConfig);
  fsm.SetOnEntering(MONITOR_AMBIENTAL, entrarMonitorAmbiental);
  fsm.SetOnEntering(MONITOR_INTRUSOS, entrarMonitorIntrusos);
  fsm.SetOnEntering(ALARMA, entrarAlarma);
  fsm.SetOnEntering(BLOQUEO, entrarBloqueo);
  
  fsm.SetOnLeaving(INICIO, [](){});
  fsm.SetOnLeaving(CONFIG, salirConfig);
  fsm.SetOnLeaving(MONITOR_AMBIENTAL, salirMonitorAmbiental);
  fsm.SetOnLeaving(MONITOR_INTRUSOS, salirMonitorIntrusos);
  fsm.SetOnLeaving(ALARMA, salirAlarma);
  fsm.SetOnLeaving(BLOQUEO, salirBloqueo);
}

void fsm_set_state(State nuevo) { fsm.SetState(nuevo, false, true); }
void fsm_update() { fsm.Update(); inputFSM = INPUT_UNKNOWN; }
void fsm_run_current_state() {
  switch(fsm.GetState()) {
    case INICIO: loopInicio(); break;
    case CONFIG: loopConfig(); break;
    case MONITOR_AMBIENTAL: loopMonitorAmbiental(); break;
    case MONITOR_INTRUSOS: loopMonitorIntrusos(); break;
    case ALARMA: loopAlarma(); break;
    case BLOQUEO: loopBloqueo(); break;
  }
}