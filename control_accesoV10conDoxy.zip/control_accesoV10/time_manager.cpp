/**
 * @file time_manager.cpp
 * @brief Implementación de hora simulada.
 */

#include <Arduino.h>
#include "time_manager.h"

byte horaActual = 0;
byte minutoActual = 0;
bool horaConfigurada = false;

static byte horaBase = 0;
static byte minBase = 0;
static unsigned long tInicioSistema = 0;

void time_init() {}

/**
 * @brief Actualiza hora simulada basada en millis().
 */
void time_update() {
  if (!horaConfigurada) return;
  
  unsigned long elapsed = (millis() - tInicioSistema) / 1000UL;
  unsigned long totalMin = (unsigned long)horaBase * 60 + minBase + elapsed / 60;
  
  horaActual   = (byte)((totalMin / 60) % 24);
  minutoActual = (byte)(totalMin % 60);
}

/**
 * @brief Configura hora inicial.
 * @param h Hora (0-23)
 * @param m Minutos (0-59)
 */
void time_set_hora(byte h, byte m) {
  horaBase = h;
  minBase = m;
  horaActual = h;
  minutoActual = m;
  horaConfigurada = true;
  tInicioSistema = millis();
}

/**
 * @brief Valida hora ingresada.
 * @param h Hora
 * @param m Minutos
 * @return true si válida
 */
bool time_validar(byte h, byte m) { return (h < 24 && m < 60); }