/**
 * @file tasks.cpp
 * @brief Implementación de tareas asíncronas.
 */
 
#include <Arduino.h>
#include "constants.h"
#include "tasks.h"
#include "fsm.h"
#include "lcd_display.h"
#include "actuators.h"
#include "eeprom.h"
#include "keypad_handler.h"

extern byte cont_intentos;
extern byte cont_alarmas;
extern byte idxHora;
extern bool cambioClaveActivo;
extern byte faseClave;
extern byte idxNueva;
extern int usuario_actual;
extern char claveNueva1[];
extern char claveNueva2[];

/**
 * @brief Callback: fuera de franja horaria.
 */
void onFueraFranja() {
  inputFSM = INPUT_UNKNOWN;
  lcd.clear();
  lcd.print("Ingrese clave:");
}

/**
 * @brief Callback: clave incorrecta.
 */
void onClaveIncorrecta() {
  if (cont_intentos >= NUM_INTENTOS) {
    setLED(true, false, false);
    inputFSM = INPUT_BLOQUEADO;
  } else {
    setLED(false, false, true);
    lcd.clear();
    lcd.print("Intentos:");
    lcd.setCursor(9, 0);
    lcd.print(cont_intentos);
    lcd.print("/"); lcd.print(NUM_INTENTOS);
    setLED(false, false, false);
    lcd.clear();
    lcd.print("Ingrese clave:");
  }
}

/**
 * @brief Callback: hora aceptada.
 */
void onHoraOk() {
  lcd.clear();
  lcd.print("Ingrese clave:");
}

/**
 * @brief Callback: hora inválida.
 */
void onHoraInvalida() {
  idxHora = 0;
  lcd.clear();
  lcd.print("Ingrese hora:");
  lcd.setCursor(0, 1);
  lcd.print("HHMM: ");
}

/**
 * @brief Callback: tarjeta RFID inválida.
 */
void onTarjetaInvalida() {
  lcd.clear();
  lcd.print("Ingrese clave:");
}

/**
 * @brief Callback: claves no coinciden.
 */
void onNoCoinciden() {
  faseClave = 1;
  idxNueva = 0;
  lcd.clear();
  lcd.print("Nueva clave:");
}

/**
 * @brief Callback: clave ya usada en historial.
 */
void onClaveYaUsada() {
  faseClave = 1;
  idxNueva = 0;
  lcd.clear();
  lcd.print("Nueva clave:");
}

/**
 * @brief Callback: clave cambiada exitosamente.
 */
void onClaveCambiada() {
  cambioClaveActivo = false;
  faseClave = 0;
  idxNueva = 0;
  lcd.clear();
  lcd.print("Puerta cerrada");
  lcd.setCursor(0, 1);
  lcd.print("A:clave  D:OK");
}

/**
 * @brief Callback: intrusión detectada.
 */
void onIntrusoDetectado() { inputFSM = INPUT_SENSOR_MAL; }

/**
 * @brief Callback: 3 alarmas en 12s.
 */
void on3Alarmas() {
  cont_alarmas = 0;
  inputFSM = INPUT_RESET;
}

/** @brief Creación de tareas (periodo ms, repetir, callback). */
AsyncTask TaskFueraFranja(1500, false, onFueraFranja);
AsyncTask TaskClaveInc(1000, false, onClaveIncorrecta);
AsyncTask TaskHoraOk(800, false, onHoraOk);
AsyncTask TaskHoraInv(800, false, onHoraInvalida);
AsyncTask TaskTarjetaInv(1000, false, onTarjetaInvalida);
AsyncTask TaskNoCoinciden(1000, false, onNoCoinciden);
AsyncTask TaskClaveYaUsada(1000, false, onClaveYaUsada);
AsyncTask TaskClaveCambiada(1200, false, onClaveCambiada);
AsyncTask TaskIntrusoDet(500, false, onIntrusoDetectado);
AsyncTask Task3Alarmas(800, false, on3Alarmas);

void tasks_init() {}

/**
 * @brief Actualiza todas las tareas de mensajes.
 */
void tasks_update_all() {
  TaskFueraFranja.Update();
  TaskClaveInc.Update();
  TaskHoraOk.Update();
  TaskHoraInv.Update();
  TaskTarjetaInv.Update();
  TaskNoCoinciden.Update();
  TaskClaveYaUsada.Update();
  TaskClaveCambiada.Update();
  TaskIntrusoDet.Update();
  Task3Alarmas.Update();
}