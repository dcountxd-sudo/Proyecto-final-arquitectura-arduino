/**
 * @file keypad_handler.cpp
 * @brief Implementación de teclado y RFID.
 */

#include <Arduino.h>
#include "keypad_handler.h"

/** @brief Mapa de teclas. */
const byte ROWS = 4, COLS = 4;
char keys[ROWS][COLS] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};
byte rowPins[ROWS] = ROW_PINS;
byte colPins[COLS] = COL_PINS;
Keypad teclado = Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS);

MFRC522 rfid(PIN_RFID_SS, PIN_RFID_RST);

char clave_ingresada[NUM_DIGIT + 1] = {0};
byte idx_clave = 0;

/**
 * @brief Inicializa teclado (vacío).
 */
void keypad_init() {}

/**
 * @brief Lee tecla presionada (no bloqueante).
 * @return Carácter de la tecla o 0
 */
char keypad_get_key() { return teclado.getKey(); }

/**
 * @brief Limpia buffer de clave ingresada.
 */
void keypad_limpiar_buffer() {
  memset(clave_ingresada, 0, sizeof(clave_ingresada));
  idx_clave = 0;
}

/**
 * @brief Inicializa RFID.
 */
void rfid_init() {
  SPI.begin();
  rfid.PCD_Init();
}

/**
 * @brief Lee UID de tarjeta RFID.
 * @param uid_buffer Buffer de 4 bytes
 * @return 0 si éxito, -1 si no hay tarjeta
 */
int rfid_leer_uid(byte* uid_buffer) {
  if (!rfid.PICC_IsNewCardPresent()) return -1;
  if (!rfid.PICC_ReadCardSerial()) return -1;
  
  for (byte i = 0; i < rfid.uid.size && i < MAX_UID; i++) {
    uid_buffer[i] = rfid.uid.uidByte[i];
  }
  rfid.PICC_HaltA();
  return 0;
}