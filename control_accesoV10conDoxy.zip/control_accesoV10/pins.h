/**
 * @file pins.h
 * @brief Definición de pines del hardware.
 */

#ifndef PINS_H
#define PINS_H

#include <Arduino.h>

/** @name LED RGB */
///@{
#define PIN_RED      22   ///< LED rojo
#define PIN_GREEN    26   ///< LED verde
#define PIN_BLUE     24   ///< LED azul
///@}

/** @name Actuadores */
///@{
#define PIN_BUZZER    6   ///< Buzzer activo (LOW=suena)
#define PIN_SERVO     8   ///< Servo motor
#define PIN_BOTON    10   ///< Botón físico (INPUT_PULLUP)
///@}

/** @name Sensores analógicos */
///@{
#define PIN_TEMP     A8   ///< Termistor NTC
#define PIN_LUZ      A7   ///< LDR
#define PIN_HALL     A6   ///< Sensor Hall
#define PIN_MIC_AN   A5   ///< Micrófono analógico
///@}

/** @name Sensores digitales */
#define PIN_MIC_DIG   7   ///< Micrófono digital

/** @name RFID */
#define PIN_RFID_SS  53   ///< SPI Slave Select
#define PIN_RFID_RST  9   ///< Reset

/** @name Teclado 4x4 */
#define KEYPAD_ROWS   4
#define KEYPAD_COLS   4
#define ROW_PINS      {25, 27, 29, 31}
#define COL_PINS      {33, 35, 37, 39}

#endif