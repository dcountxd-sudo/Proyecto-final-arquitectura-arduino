/**
 * @file lcd_display.cpp
 * @brief Implementación de funciones LCD.
 */

#include <Arduino.h>
#include "lcd_display.h"
#include "constants.h"

LiquidCrystal lcd(12, 11, 5, 4, 3, 2);

/**
 * @brief Inicializa LCD.
 */
void lcd_init() {
  lcd.begin(16, 2);
  lcd.print("Iniciando...");
  delay(500);
  lcd.clear();
}

/**
 * @brief Muestra estado actual en línea superior.
 * @param estado Número de estado (0-5)
 */
void lcd_estado(int estado) {
  lcd.setCursor(0, 0);
  lcd.print("                ");
  lcd.setCursor(0, 0);
  switch(estado) {
    case 0: lcd.print("INICIO  "); break;
    case 1: lcd.print("CONFIG  "); break;
    case 2: lcd.print("AMB     "); break;
    case 3: lcd.print("INTRUS  "); break;
    case 4: lcd.print("ALARMA! "); break;
    case 5: lcd.print("BLOQ    "); break;
    default: lcd.print("UNKNOWN "); break;
  }
}

/**
 * @brief Muestra mensaje temporal (bloqueante).
 * @param linea1 Texto línea 1
 * @param linea2 Texto línea 2
 * @param espera Duración en ms
 */
void lcd_mensaje(const char* linea1, const char* linea2, unsigned long espera) {
  lcd.clear();
  lcd.setCursor(0, 0); lcd.print(linea1);
  lcd.setCursor(0, 1); lcd.print(linea2);
  delay(espera);
}

/**
 * @brief Muestra clave enmascarada con asteriscos.
 * @param digitos Cantidad de dígitos ingresados
 */
void lcd_clave(byte digitos) {
  lcd.setCursor(0, 1);
  lcd.print("Clave:          ");
  lcd.setCursor(7, 1);
  for (byte i = 0; i < digitos; i++) lcd.print('*');
}

/**
 * @brief Muestra temperatura y luz en MONITOR_AMBIENTAL.
 * @param temp Temperatura (°C)
 * @param luz  Valor ADC del LDR
 */
void lcd_sensores_ambiental(float temp, int luz) {
  lcd.setCursor(0, 1);
  lcd.print("T:"); lcd.print(temp, 1);
  lcd.print("C L:"); lcd.print(luz / 10);
  lcd.print("   ");
}

/**
 * @brief Muestra Hall y Mic en MONITOR_INTRUSOS.
 * @param hall Valor ADC del Hall
 * @param mic  Valor ADC del micrófono
 */
void lcd_sensores_intrusos(int hall, int mic) {
  lcd.setCursor(0, 1);
  lcd.print("H:"); lcd.print(hall);
  lcd.print(" M:"); lcd.print(mic);
  lcd.print("   ");
}

/**
 * @brief Pantalla de ingreso de hora.
 */
void lcd_ingresar_hora() {
  lcd.clear();
  lcd.print("Ingrese hora:");
  lcd.setCursor(0, 1);
  lcd.print("HHMM: ");
}

/**
 * @brief Pantalla de ingreso de clave.
 */
void lcd_ingresar_clave() {
  lcd.clear();
  lcd.print("Ingrese clave:");
}

/**
 * @brief Pantalla de bienvenida.
 * @param nombre Nombre del usuario
 */
void lcd_bienvenido(const char* nombre) {
  lcd.clear();
  lcd.print("Bienvenido:");
  lcd.setCursor(0, 1);
  lcd.print(nombre);
}

/**
 * @brief Pantalla de puerta cerrada con opciones.
 * @param cambioActivo true=obliga cambiar clave
 */
void lcd_puerta_cerrada(bool cambioActivo) {
  lcd.clear();
  lcd.print("Puerta cerrada");
  lcd.setCursor(0, 1);
  if (cambioActivo) {
    lcd.print("A:cambiar clave");
  } else {
    lcd.print("A:clave  D:OK");
  }
}

/**
 * @brief Pantalla para ingresar nueva clave.
 */
void lcd_nueva_clave() {
  lcd.clear();
  lcd.print("Nueva clave:");
  lcd.setCursor(0, 1);
  lcd.print("(4 digitos)");
}

/**
 * @brief Pantalla para confirmar nueva clave.
 */
void lcd_confirmar_clave() {
  lcd.clear();
  lcd.print("Confirme clave:");
}

/**
 * @brief Muestra contador de alarmas.
 * @param contAlarmas Número de alarmas
 */
void lcd_alarma(int contAlarmas) {
  lcd.setCursor(0, 1);
  lcd.print("Alarmas: ");
  lcd.print(contAlarmas);
  lcd.print("   ");
}