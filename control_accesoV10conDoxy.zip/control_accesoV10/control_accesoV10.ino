/**
 * @file control_accesoV10.ino
 * @brief Punto de entrada del sistema.
 */

#include "pins.h"
#include "constants.h"
#include "eeprom.h"
#include "sensors.h"
#include "actuators.h"
#include "lcd_display.h"
#include "keypad_handler.h"
#include "time_manager.h"
#include "tasks.h"
#include "fsm.h"

/**
 * @brief Inicializa todo el sistema.
 */
void setup() {
  Serial.begin(9600);

  actuators_init();
  lcd_init();
  keypad_init();
  rfid_init();
  eeprom_init();
  sensors_init();
  time_init();
  tasks_init();

  // Forzar UID de la tarjeta (solo primera vez o si cambia)
  Usuario u;
  leerUsuario(8, u);
  u.uid[0] = 0xF3; u.uid[1] = 0xAF; u.uid[2] = 0x2B; u.uid[3] = 0x27;
  guardarUsuario(8, u);

  fsm_init();
  fsm_set_state(INICIO);
  Serial.println(F("[SYS] Sistema listo."));
}

/**
 * @brief Loop principal: actualiza hora, tareas, FSM y botón.
 */
void loop() {
  time_update();
  tasks_update_all();
  fsm_run_current_state();
  fsm_update();
  if (boton_presionado()) inputFSM = INPUT_RESET;
}