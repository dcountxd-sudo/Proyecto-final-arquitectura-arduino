/**
 * @file eeprom.h
 * @brief Gestión de usuarios en EEPROM.
 */

#ifndef EEPROM_H
#define EEPROM_H

#include <Arduino.h>
#include <EEPROM.h>
#include "constants.h"

/** @brief Roles del sistema. */
enum Rol { ROL_SEGURIDAD, ROL_OPERARIO, ROL_COORDINADOR, ROL_GERENTE };

/** @brief Estructura de usuario almacenada en EEPROM. */
struct Usuario {
  char nombre[MAX_NOMBRE];                      ///< Nombre
  int  permiso[2];                              ///< [horaInicio, horaFin]
  char clave[MAX_CLAVE];                        ///< Clave actual
  char historial[MAX_HISTORIAL][MAX_CLAVE];     ///< Últimas 4 claves
  byte usos;                                    ///< Contador de usos
  byte uid[MAX_UID];                            ///< UID de tarjeta RFID
  Rol  perfil;                                  ///< Rol
};

void eeprom_init();
void guardarUsuario(int idx, const Usuario &u);
void leerUsuario(int idx, Usuario &u);
int  buscarPorClave(const char* clave);
int  buscarPorUID(const byte* uid);
bool claveRepetida(const Usuario &u, const char* clave);
void cambiarClave(int idx, const char* nuevaClave);
bool dentroFranja(const Usuario &u, byte horaActual);

#endif