/**
 * @file sensors.h
 * @brief Lectura de sensores con tareas asíncronas.
 */

#ifndef SENSORS_H
#define SENSORS_H

#include <Arduino.h>
#include "pins.h"
#include "AsyncTaskLib.h"

extern float tempLeida;
extern int   luzLeida;
extern int   hallLeido;
extern int   micLeido;
extern int   micDig;

void sensors_init();
void sensors_update_tasks();
void sensors_start_ambient_tasks();
void sensors_stop_ambient_tasks();
void sensors_start_intrusos_tasks();
void sensors_stop_intrusos_tasks();

/** @name Lecturas inmediatas (sin esperar tasks) */
///@{
void leer_temperatura_inmediato();
void leer_luz_inmediato();
void leer_hall_inmediato();
void leer_microfono_inmediato();
///@}

#endif