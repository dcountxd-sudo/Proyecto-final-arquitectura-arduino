#include <Arduino.h>
#include "constants.h"
#include "sensors.h"

float tempLeida = 0;
int   luzLeida  = 0;
int   hallLeido = 0;
int   micLeido  = 0;
int   micDig    = 0;

// Funciones de lectura
static void leer_temperatura() {
  int raw = analogRead(PIN_TEMP);
  if (raw == 0) raw = 1;
  float R = 10000.0 * ((1023.0 / (float)raw) - 1.0);
  float logR = log(R);
  float T = 1.0 / (0.001129148 + 0.000234125 * logR + 0.0000000876741 * logR * logR * logR);
  tempLeida = T - 273.15;
  Serial.print("Temp: "); Serial.println(tempLeida);
}

static void leer_luz() {
  luzLeida = analogRead(PIN_LUZ);
  Serial.print("Luz: "); Serial.println(luzLeida);
}

static void leer_hall() {
  hallLeido = analogRead(PIN_HALL);
  Serial.print("Hall: "); Serial.println(hallLeido);
}

static void leer_microfono() {
  micLeido = analogRead(PIN_MIC_AN);
  micDig   = digitalRead(PIN_MIC_DIG);
  Serial.print("Mic: "); Serial.println(micLeido);
}

// Tasks
AsyncTask taskTemp(TASK_TEMP_PERIOD, true, leer_temperatura);
AsyncTask taskLuz(TASK_LUZ_PERIOD, true, leer_luz);
AsyncTask taskHall(TASK_HALL_PERIOD, true, leer_hall);
AsyncTask taskMic(TASK_MIC_PERIOD, true, leer_microfono);

void sensors_init() {
  pinMode(PIN_MIC_DIG, INPUT);
}

void sensors_update_tasks() {
  taskTemp.Update();
  taskLuz.Update();
  taskHall.Update();
  taskMic.Update();
}

void sensors_start_ambient_tasks() {
  taskTemp.Start();
  taskLuz.Start();
}

void sensors_stop_ambient_tasks() {
  taskTemp.Stop();
  taskLuz.Stop();
}

void sensors_start_intrusos_tasks() {
  Serial.println("Iniciando Hall y Mic");
  taskHall.Start();
  taskMic.Start();
}

void sensors_stop_intrusos_tasks() {
  taskHall.Stop();
  taskMic.Stop();
}