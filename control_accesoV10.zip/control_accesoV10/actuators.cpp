#include <Arduino.h>
#include "actuators.h"

static Servo servoMotor;
static bool ledRojoState = false;
static unsigned long tLedRojo = 0;
static unsigned long tUltimoBoton = 0;

void actuators_init() {
  pinMode(PIN_RED,    OUTPUT);
  pinMode(PIN_GREEN,  OUTPUT);
  pinMode(PIN_BLUE,   OUTPUT);
  pinMode(PIN_BUZZER, OUTPUT);
  pinMode(PIN_BOTON,  INPUT_PULLUP);
  
  digitalWrite(PIN_BUZZER, LOW);  // Apagado
  setLED(false, false, false);
  
  servoMotor.attach(PIN_SERVO);
  servoMotor.write(0);
}

void setLED(bool r, bool g, bool b) {
  digitalWrite(PIN_RED,   r ? HIGH : LOW);
  digitalWrite(PIN_GREEN, g ? HIGH : LOW);
  digitalWrite(PIN_BLUE,  b ? HIGH : LOW);
}

void apagarTodo() {
  setLED(false, false, false);
  digitalWrite(PIN_BUZZER, LOW);
}

void parpadeoRojo(unsigned long onTime, unsigned long offTime) {
  unsigned long ahora = millis();
  unsigned long intervalo = ledRojoState ? onTime : offTime;
  if (ahora - tLedRojo >= intervalo) {
    ledRojoState = !ledRojoState;
    digitalWrite(PIN_RED, ledRojoState ? HIGH : LOW);
    tLedRojo = ahora;
  }
}

void servo_abrir() {
  servoMotor.write(90);
}

void servo_cerrar() {
  servoMotor.write(0);
}

void buzzer_on() {
  digitalWrite(PIN_BUZZER, HIGH);
}

void buzzer_off() {
  digitalWrite(PIN_BUZZER, LOW);
}

bool boton_presionado() {
  if (digitalRead(PIN_BOTON) == LOW) {
    if (millis() - tUltimoBoton > T_DEBOUNCE) {
      tUltimoBoton = millis();
      return true;
    }
  }
  return false;
}