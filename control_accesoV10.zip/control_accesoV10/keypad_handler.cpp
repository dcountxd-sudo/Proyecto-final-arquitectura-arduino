#include <Arduino.h>
#include "keypad_handler.h"

// Teclado
const byte ROWS = 4, COLS = 4;
char keys[ROWS][COLS] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};
byte rowPins[ROWS] = ROW_PINS;
byte colPins[COLS] = COL_PINS;
Keypad teclado = Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS);

// RFID
MFRC522 rfid(PIN_RFID_SS, PIN_RFID_RST);

// Variables globales
char clave_ingresada[NUM_DIGIT + 1] = {0};
byte idx_clave = 0;

void keypad_init() {}

char keypad_get_key() {
  return teclado.getKey();
}

void keypad_limpiar_buffer() {
  memset(clave_ingresada, 0, sizeof(clave_ingresada));
  idx_clave = 0;
}

void rfid_init() {
  SPI.begin();
  rfid.PCD_Init();
}

int rfid_leer_uid(byte* uid_buffer) {
  if (!rfid.PICC_IsNewCardPresent()) return -1;
  if (!rfid.PICC_ReadCardSerial()) return -1;
  
  for (byte i = 0; i < rfid.uid.size && i < MAX_UID; i++) {
    uid_buffer[i] = rfid.uid.uidByte[i];
  }
  rfid.PICC_HaltA();
  return 0;
}