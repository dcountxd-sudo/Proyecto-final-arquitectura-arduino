#ifndef TIME_MANAGER_H
#define TIME_MANAGER_H

#include <Arduino.h>

extern byte horaActual;
extern byte minutoActual;
extern bool horaConfigurada;

void time_init();
void time_update();
void time_set_hora(byte h, byte m);
bool time_validar(byte h, byte m);

#endif