#include <Arduino.h>
#include "eeprom.h"
#include "time_manager.h"

#define EEPROM_MARCA_ADDR  (MAX_USUARIOS * sizeof(Usuario))

static const Usuario USUARIOS_INICIALES[MAX_USUARIOS] = {
  {"Gerente1",   {8, 23}, "1111", {{"0000"},{"0000"},{"0000"},{"0000"}}, 0, {0,0,0,0}, ROL_GERENTE},
  {"Coord1",     {7, 18}, "2222", {{"0000"},{"0000"},{"0000"},{"0000"}}, 0, {0,0,0,0}, ROL_COORDINADOR},
  {"Coord2",     {7, 18}, "2233", {{"0000"},{"0000"},{"0000"},{"0000"}}, 0, {0,0,0,0}, ROL_COORDINADOR},
  {"Operario1",  {6, 16}, "3333", {{"0000"},{"0000"},{"0000"},{"0000"}}, 0, {0,0,0,0}, ROL_OPERARIO},
  {"Operario2",  {6, 16}, "3344", {{"0000"},{"0000"},{"0000"},{"0000"}}, 0, {0,0,0,0}, ROL_OPERARIO},
  {"Operario3",  {6, 16}, "3355", {{"0000"},{"0000"},{"0000"},{"0000"}}, 0, {0,0,0,0}, ROL_OPERARIO},
  {"Operario4",  {6, 16}, "3366", {{"0000"},{"0000"},{"0000"},{"0000"}}, 0, {0,0,0,0}, ROL_OPERARIO},
  {"Operario5",  {6, 16}, "3377", {{"0000"},{"0000"},{"0000"},{"0000"}}, 0, {0,0,0,0}, ROL_OPERARIO},
  {"Seguridad1", {0, 23}, "4444", {{"0000"},{"0000"},{"0000"},{"0000"}}, 0, {0x56,0x34,0xDA,0x73}, ROL_SEGURIDAD},
  {"Seguridad2", {0, 23}, "4455", {{"0000"},{"0000"},{"0000"},{"0000"}}, 0, {0x43,0x89,0x4F,0x2E}, ROL_SEGURIDAD}
};

void eeprom_init() {
  byte marca;
  EEPROM.get(EEPROM_MARCA_ADDR, marca);
  

  
 if (marca != EEPROM_MARCA_VAL) {
    for (int i = 0; i < MAX_USUARIOS; i++) {
      guardarUsuario(i, USUARIOS_INICIALES[i]);
    }
    EEPROM.put(EEPROM_MARCA_ADDR, (byte)EEPROM_MARCA_VAL);
    Serial.println(F("[EEPROM] Usuarios inicializados."));
  } else {
    Serial.println(F("[EEPROM] Usuarios cargados."));
  }
    // DEPURACIÓN: Mostrar claves de todos los usuarios
    Serial.println("=== CLAVES EN EEPROM ===");
    for (int i = 0; i < MAX_USUARIOS; i++) {
      Usuario u;
      leerUsuario(i, u);
      Serial.print("Usuario ");
      Serial.print(i);
      Serial.print(": ");
      Serial.print(u.nombre);
      Serial.print(" -> Clave: ");
      Serial.println(u.clave);
    }
    Serial.println("=========================");

}

void guardarUsuario(int idx, const Usuario &u) {
  EEPROM.put(idx * sizeof(Usuario), u);
}

void leerUsuario(int idx, Usuario &u) {
  EEPROM.get(idx * sizeof(Usuario), u);
}

int buscarPorClave(const char* clave) {
  for (int i = 0; i < MAX_USUARIOS; i++) {
    Usuario u;
    leerUsuario(i, u);
    if (strcmp(u.clave, clave) == 0) return i;
  }
  return -1;
}

static bool isEqualArray(const byte* a, const byte* b, int len) {
  for (int i = 0; i < len; i++) {
    if (a[i] != b[i]) return false;
  }
  return true;
}

int buscarPorUID(const byte* uid) {
  for (int i = 0; i < MAX_USUARIOS; i++) {
    Usuario u;
    leerUsuario(i, u);
    if (isEqualArray(u.uid, uid, MAX_UID) &&
        !(u.uid[0]==0 && u.uid[1]==0 && u.uid[2]==0 && u.uid[3]==0)) {
      return i;
    }
  }
  return -1;
}

bool claveRepetida(const Usuario &u, const char* clave) {
  for (int i = 0; i < MAX_HISTORIAL; i++) {
    if (strcmp(u.historial[i], clave) == 0) return true;
  }
  return false;
}

void cambiarClave(int idx, const char* nuevaClave) {
  Usuario u;
  leerUsuario(idx, u);
  for (int i = MAX_HISTORIAL - 1; i > 0; i--) {
    strcpy(u.historial[i], u.historial[i-1]);
  }
  strcpy(u.historial[0], u.clave);
  strcpy(u.clave, nuevaClave);
  u.usos = 0;
  guardarUsuario(idx, u);
}

bool dentroFranja(const Usuario &u, byte horaActual) {
  return (horaActual >= u.permiso[0] && horaActual < u.permiso[1]);
}