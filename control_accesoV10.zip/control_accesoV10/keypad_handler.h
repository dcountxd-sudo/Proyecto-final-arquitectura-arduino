#include <Arduino.h>
#ifndef KEYPAD_HANDLER_H
#define KEYPAD_HANDLER_H

#include <Keypad.h>
#include <MFRC522.h>
#include "pins.h"
#include "constants.h"

void keypad_init();
void rfid_init();
char keypad_get_key();
int  rfid_leer_uid(byte* uid_buffer);
void keypad_limpiar_buffer();

extern char clave_ingresada[NUM_DIGIT + 1];
extern byte idx_clave;

#endif