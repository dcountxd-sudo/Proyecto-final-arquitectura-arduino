#include "pins.h"
#include "constants.h"
#include "eeprom.h"
#include "sensors.h"
#include "actuators.h"
#include "lcd_display.h"
#include "keypad_handler.h"
#include "time_manager.h"
#include "tasks.h"
#include "fsm.h"

void setup() {
  // BORRAR EEPROM (solo una vez)
  /**for (int i = 0; i < 512; i++) {
    EEPROM.write(i, 0);
  }
  Serial.println("EEPROM borrada");
  **/// ... resto del setup

  Serial.begin(9600);

  actuators_init();
  lcd_init();
  keypad_init();
  rfid_init();
  eeprom_init();
  sensors_init();
  time_init();
  tasks_init();
  
  fsm_init();
  fsm_set_state(INICIO);
  
  Serial.println(F("[SYS] Sistema listo."));
}

void loop() {
  time_update();
  tasks_update_all();        // ← Actualiza todas las tasks mensaje // ← Esta función debe existir o la creamos
  
  fsm_run_current_state();
  fsm_update();
  
  // Botón físico solo para RESET (vuelve a INICIO desde cualquier estado)
  if (boton_presionado()) {
    inputFSM = INPUT_RESET;
  }
}