#include <Arduino.h>
#ifndef CONSTANTS_H
#define CONSTANTS_H

// ============================================================
// TIEMPOS (ms)
// ============================================================
#define T_MONITOR_AMB       5000UL   // Ambiental → Intrusos
#define T_MONITOR_INT       2000UL   // Intrusos → Ambiental
#define T_ALARMA_AMB        4000UL   // Alarma desde Ambiental
#define T_ALARMA_INT        2000UL   // Alarma desde Intrusos
#define T_ALARMA_MAX       12000UL   // Ventana para 3 alarmas
#define T_PUERTA_ABIERTA    3000UL   // Tiempo puerta abierta
#define T_BIENVENIDA        1500UL   // Duración mensaje bienvenida
#define T_DEBOUNCE           200UL   // Anti-rebote botón
#define NUM_INTENTOS             3

// Parpadeo LED rojo
#define T_BLOQUEO_ON         100UL
#define T_BLOQUEO_OFF        500UL
#define T_ALARMA_ON          300UL
#define T_ALARMA_OFF         700UL

// ============================================================
// UMBRALES DE SENSORES
// ============================================================
#define UMBRAL_TEMP_BAJO     20      // °C (frío)
#define UMBRAL_TEMP_ALTO     30      // °C (calor)
#define UMBRAL_LUZ_BAJO     100      // ADC (oscuridad)
#define UMBRAL_HALL         512      // ADC (puerta abierta)
#define UMBRAL_MIC          510      // ADC (ruido alto)
#define UMBRAL_MIC_VECES      3      // Detecciones consecutivas

// ============================================================
// EEPROM
// ============================================================
#define MAX_USUARIOS        10
#define MAX_NOMBRE          20
#define NUM_DIGIT            4
#define MAX_CLAVE            5       // NUM_DIGIT + 1
#define MAX_HISTORIAL        4
#define MAX_UID              4
#define MAX_INTENTOS         3
#define MAX_USOS             4
#define EEPROM_MARCA_VAL   0xAB

// ============================================================
// TAREAS ASÍNCRONAS (periodos en ms)
// ============================================================
#define TASK_TEMP_PERIOD    1800
#define TASK_LUZ_PERIOD     1700
#define TASK_HALL_PERIOD    500
#define TASK_MIC_PERIOD      300

#endif