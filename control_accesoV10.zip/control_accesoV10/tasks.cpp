#include <Arduino.h>
#include "constants.h"
#include "tasks.h"
#include "fsm.h"
#include "lcd_display.h"
#include "actuators.h"
#include "eeprom.h"
#include "keypad_handler.h"

// Variables externas necesarias
extern byte cont_intentos;
extern byte cont_alarmas;
extern byte idxHora;
extern bool cambioClaveActivo;
extern byte faseClave;
extern byte idxNueva;
extern int usuario_actual;
extern char claveNueva1[];
extern char claveNueva2[];

// ============================================================
// CALLBACKS DE LAS TASKS
// ============================================================

void onFueraFranja() {
  inputFSM = INPUT_UNKNOWN;
  lcd.clear();
  lcd.print("Ingrese clave:");
}

void onClaveIncorrecta() {
  if (cont_intentos >= NUM_INTENTOS) {
    setLED(true, false, false);
    inputFSM = INPUT_BLOQUEADO;
  } else {
    setLED(false, false, true);
    lcd.clear();
    lcd.print("Intentos:");
    lcd.setCursor(9, 0);
    lcd.print(cont_intentos);
    lcd.print("/");
    lcd.print(NUM_INTENTOS);
    setLED(false, false, false);
    lcd.clear();
    lcd.print("Ingrese clave:");
  }
}

void onHoraOk() {
  lcd.clear();
  lcd.print("Ingrese clave:");
}

void onHoraInvalida() {
  idxHora = 0;
  lcd.clear();
  lcd.print("Ingrese hora:");
  lcd.setCursor(0, 1);
  lcd.print("HHMM: ");
}

void onTarjetaInvalida() {
  lcd.clear();
  lcd.print("Ingrese clave:");
}

void onNoCoinciden() {
  faseClave = 1;
  idxNueva = 0;
  lcd.clear();
  lcd.print("Nueva clave:");
}

void onClaveYaUsada() {
  faseClave = 1;
  idxNueva = 0;
  lcd.clear();
  lcd.print("Nueva clave:");
}

void onClaveCambiada() {
  cambioClaveActivo = false;
  faseClave = 0;
  idxNueva = 0;
  lcd.clear();
  lcd.print("Puerta cerrada");
  lcd.setCursor(0, 1);
  lcd.print("A:clave  D:OK");
}

void onIntrusoDetectado() {
  inputFSM = INPUT_SENSOR_MAL;
}

void on3Alarmas() {
  cont_alarmas = 0;
  inputFSM = INPUT_RESET;
}

// ============================================================
// DECLARACIÓN DE LAS TASKS
// ============================================================

AsyncTask TaskFueraFranja(1500, false, onFueraFranja);
AsyncTask TaskClaveInc(1000, false, onClaveIncorrecta);
AsyncTask TaskHoraOk(800, false, onHoraOk);
AsyncTask TaskHoraInv(800, false, onHoraInvalida);
AsyncTask TaskTarjetaInv(1000, false, onTarjetaInvalida);
AsyncTask TaskNoCoinciden(1000, false, onNoCoinciden);
AsyncTask TaskClaveYaUsada(1000, false, onClaveYaUsada);
AsyncTask TaskClaveCambiada(1200, false, onClaveCambiada);
AsyncTask TaskIntrusoDet(500, false, onIntrusoDetectado);
AsyncTask Task3Alarmas(800, false, on3Alarmas);

// ============================================================
// INICIALIZACIÓN
// ============================================================

void tasks_init() {
  // No es necesario iniciarlas aquí, se inician cuando se necesitan
}

void tasks_update_all() {
  TaskFueraFranja.Update();
  TaskClaveInc.Update();
  TaskHoraOk.Update();
  TaskHoraInv.Update();
  TaskTarjetaInv.Update();
  TaskNoCoinciden.Update();
  TaskClaveYaUsada.Update();
  TaskClaveCambiada.Update();
  TaskIntrusoDet.Update();
  Task3Alarmas.Update();
}