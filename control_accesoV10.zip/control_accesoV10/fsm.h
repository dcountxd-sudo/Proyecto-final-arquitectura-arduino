#include <Arduino.h>
#ifndef FSM_H
#define FSM_H

#include "StateMachineLib.h"

extern byte cont_intentos;
extern byte cont_alarmas;
extern byte cont_mic;
extern int  usuario_actual;
extern char claveNueva1[];
extern char claveNueva2[];
extern byte idxNueva;
extern byte faseClave;

enum State {
  INICIO            = 0,
  CONFIG            = 1,
  MONITOR_AMBIENTAL = 2,
  MONITOR_INTRUSOS  = 3,
  ALARMA            = 4,
  BLOQUEO           = 5
};

enum Input {
  INPUT_CLAVE_OK   = 0,
  INPUT_BLOQUEADO  = 1,
  INPUT_SENSOR_MAL = 2,

  INPUT_TO_AMBIENTAL = 3,
  INPUT_TO_INTRUSOS  = 4,

  INPUT_ALARMA_AMB = 5,
  INPUT_ALARMA_INT = 6,

  INPUT_RESET      = 7,
  INPUT_UNKNOWN    = 8
};

extern Input inputFSM;

void fsm_init();
void fsm_set_state(State nuevo);
void fsm_update();
void fsm_run_current_state();

#endif