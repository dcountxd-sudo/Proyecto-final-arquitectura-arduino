#ifndef TASKS_H
#define TASKS_H

#include <Arduino.h>
#include "AsyncTaskLib.h"
#include "constants.h"

// ============================================================
// DECLARACIONES DE TASKS (solo una vez cada una)
// ============================================================
extern AsyncTask TaskHoraOk;
extern AsyncTask TaskHoraInv;
extern AsyncTask TaskClaveInc;
extern AsyncTask TaskFueraFranja;
extern AsyncTask TaskTarjetaInv;
extern AsyncTask TaskNoCoinciden;
extern AsyncTask TaskClaveYaUsada;
extern AsyncTask TaskClaveCambiada;
extern AsyncTask TaskIntrusoDet;
extern AsyncTask Task3Alarmas;

// Tasks de sensores
extern AsyncTask taskTemp;
extern AsyncTask taskLuz;
extern AsyncTask taskHall;
extern AsyncTask taskMic;

// ============================================================
// VARIABLES GLOBALES QUE TASKS NECESITA (extern)
// ============================================================
extern byte idxHora;
extern bool cambioClaveActivo;
extern byte faseClave;
extern byte idxNueva;
extern int usuario_actual;
extern byte cont_intentos;
extern byte cont_alarmas;
extern char claveNueva1[];
extern char claveNueva2[];

// ============================================================
// FUNCIONES PÚBLICAS
// ============================================================
void tasks_init();
void tasks_update_all();

#endif