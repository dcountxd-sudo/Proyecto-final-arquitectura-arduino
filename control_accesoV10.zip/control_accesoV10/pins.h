#include <Arduino.h>
#ifndef PINS_H
#define PINS_H

// LED RGB
#define PIN_RED      22
#define PIN_GREEN    26
#define PIN_BLUE     24

// Actuadores
#define PIN_BUZZER    6
#define PIN_SERVO     8
#define PIN_BOTON    10

// Sensores analógicos
#define PIN_TEMP     A8
#define PIN_LUZ      A7
#define PIN_HALL     A6
#define PIN_MIC_AN   A5

// Sensor digital
#define PIN_MIC_DIG   7

// RFID
#define PIN_RFID_SS  53
#define PIN_RFID_RST  9

// Teclado 4x4
#define KEYPAD_ROWS   4
#define KEYPAD_COLS   4
#define ROW_PINS      {25, 27, 29, 31}
#define COL_PINS      {33, 35, 37, 39}

#endif