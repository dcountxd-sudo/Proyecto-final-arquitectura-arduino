/**
 * @file constants.h
 * @brief Constantes de tiempos, umbrales y configuración.
 */

#ifndef CONSTANTS_H
#define CONSTANTS_H

#include <Arduino.h>

/** @name Tiempos (ms) */
///@{
#define T_MONITOR_AMB       5000UL   ///< Ambiental → Intrusos
#define T_MONITOR_INT       2000UL   ///< Intrusos → Ambiental
#define T_ALARMA_AMB        4000UL   ///< Duración alarma ambiental
#define T_ALARMA_INT        2000UL   ///< Duración alarma intrusión
#define T_ALARMA_MAX       12000UL   ///< Ventana para 3 alarmas
#define T_PUERTA_ABIERTA    3000UL   ///< Tiempo puerta abierta
#define T_BIENVENIDA        1500UL   ///< Duración mensaje bienvenida
#define T_DEBOUNCE           200UL   ///< Anti-rebote botón
///@}

/** @name Parpadeo LED rojo */
///@{
#define T_BLOQUEO_ON         100UL
#define T_BLOQUEO_OFF        500UL
#define T_ALARMA_ON          300UL
#define T_ALARMA_OFF         700UL
///@}

/** @name Umbrales de sensores */
///@{
#define UMBRAL_TEMP_BAJO     24      ///< °C para alarma ambiental
#define UMBRAL_LUZ_BAJO      700     ///< ADC oscuridad
#define UMBRAL_HALL          600     ///< ADC puerta abierta
#define UMBRAL_MIC           400     ///< ADC ruido
#define UMBRAL_MIC_VECES      1      ///< Detecciones necesarias
///@}

/** @name EEPROM */
///@{
#define MAX_USUARIOS        10
#define MAX_NOMBRE          20
#define NUM_DIGIT            4
#define MAX_CLAVE            NUM_DIGIT+1
#define MAX_HISTORIAL        4
#define MAX_UID              4
#define MAX_INTENTOS         3
#define MAX_USOS             4
#define EEPROM_MARCA_VAL   0xAB
///@}

/** @name Tareas asíncronas (periodos en ms) */
///@{
#define TASK_TEMP_PERIOD    1800
#define TASK_LUZ_PERIOD     1700
#define TASK_HALL_PERIOD    500
#define TASK_MIC_PERIOD      300
///@}

#endif