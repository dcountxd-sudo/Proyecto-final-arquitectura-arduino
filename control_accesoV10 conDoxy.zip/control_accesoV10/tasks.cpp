/**
 * @file tasks.cpp
 * @brief Implementación de tareas asíncronas.
 */

#include <Arduino.h>
#include "constants.h"
#include "tasks.h"
#include "fsm.h"
#include "lcd_display.h"
#include "actuators.h"
#include "eeprom.h"
#include "keypad_handler.h"

extern byte cont_intentos;
extern byte cont_alarmas;
extern byte idxHora;
extern bool cambioClaveActivo;
extern byte faseClave;
extern byte idxNueva;
extern int usuario_actual;
extern char claveNueva1[];
extern char claveNueva2[];

/**
 * @brief Callback: fuera de franja horaria.
 */
void onFueraFranja() {
  inputFSM = INPUT_UNKNOWN;
  lcd.clear();
  lcd.print("Ingrese clave:");
}

/**
 * @brief Callback: clave incorrecta.
 */
void onClaveIncorrecta() {
  if (cont_intentos >= NUM_INTENTOS) {
    setLED(true, false, false);
    inputFSM = INPUT_BLOQUEADO;
  } else {
    setLED(false, false, true);
    lcd.clear();
    lcd.print("Intentos:");
    lcd.setCursor(9, 0);
    lcd.print(cont_int