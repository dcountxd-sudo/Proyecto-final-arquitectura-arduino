#ifndef TASKS_H
#define TASKS_H

#include "AsyncTaskLib.h"

// Tasks de mensajes (callbacks declarados en fsm.cpp)
extern AsyncTask TaskHoraOk;
extern AsyncTask TaskHoraInv;
extern AsyncTask TaskClaveInc;
extern AsyncTask TaskFueraFranja;
extern AsyncTask TaskTarjetaInv;
extern AsyncTask TaskNoCoinciden;
extern AsyncTask TaskClaveYaUsada;
extern AsyncTask TaskClaveCambiada;
extern AsyncTask TaskIntrusoDet;
extern AsyncTask Task3Alarmas;

// Tasks de sensores (declarados en sensors.cpp)
extern AsyncTask taskTemp;
extern AsyncTask taskLuz;
extern AsyncTask taskHall;
extern AsyncTask taskMic;

void tasks_init();
void tasks_update_all();

#endif