#ifndef SENSORS_H
#define SENSORS_H

#include <Arduino.h>
#include "pins.h"
#include "AsyncTaskLib.h"

extern float tempLeida;
extern int   luzLeida;
extern int   hallLeido;
extern int   micLeido;
extern int   micDig;

void sensors_init();
void sensors_update_tasks();
void sensors_start_ambient_tasks();
void sensors_stop_ambient_tasks();
void sensors_start_intrusos_tasks();
void sensors_stop_intrusos_tasks();

#endif