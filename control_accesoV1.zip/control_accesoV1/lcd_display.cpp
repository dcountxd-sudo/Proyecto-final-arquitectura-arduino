#include "lcd_display.h"
#include "constants.h"

LiquidCrystal lcd(12, 11, 5, 4, 3, 2);

void lcd_init() {
  lcd.begin(16, 2);
  lcd.print("Iniciando...");
  delay(500);
  lcd.clear();
}

void lcd_estado(int estado) {
  lcd.setCursor(0, 0);
  switch(estado) {
    case 0: lcd.print("INICIO  "); break;
    case 1: lcd.print("CONFIG  "); break;
    case 2: lcd.print("AMB     "); break;
    case 3: lcd.print("INTRUS  "); break;
    case 4: lcd.print("ALARMA! "); break;
    case 5: lcd.print("BLOQ    "); break;
    default: lcd.print("UNKNOWN "); break;
  }
}

void lcd_mensaje(const char* linea1, const char* linea2, unsigned long espera) {
  lcd.clear();
  lcd.setCursor(0, 0); lcd.print(linea1);
  lcd.setCursor(0, 1); lcd.print(linea2);
  delay(espera);
}

void lcd_clave(byte digitos) {
  lcd.setCursor(0, 1);
  lcd.print("Clave:          ");
  lcd.setCursor(7, 1);
  for (byte i = 0; i < digitos; i++) lcd.print('*');
}

void lcd_sensores_ambiental(float temp, int luz) {
  lcd.setCursor(0, 1);
  lcd.print("T:");
  lcd.print(temp, 1);
  lcd.print("C L:");
  lcd.print(luz / 10);
  lcd.print("   ");
}

void lcd_sensores_intrusos(int hall, int mic) {
  lcd.setCursor(0, 1);
  lcd.print("Hall:");
  lcd.print(hall ? 1 : 0);
  lcd.print(" Mic:");
  lcd.print(mic ? 1 : 0);
  lcd.print("   ");
}

void lcd_ingresar_hora() {
  lcd.clear();
  lcd.print("Ingrese hora:");
  lcd.setCursor(0, 1);
  lcd.print("HHMM: ");
}

void lcd_ingresar_clave() {
  lcd.clear();
  lcd.print("Ingrese clave:");
}

void lcd_bienvenido(const char* nombre) {
  lcd.clear();
  lcd.print("Bienvenido:");
  lcd.setCursor(0, 1);
  lcd.print(nombre);
}

void lcd_puerta_cerrada(bool cambioActivo) {
  lcd.clear();
  lcd.print("Puerta cerrada");
  lcd.setCursor(0, 1);
  if (cambioActivo) {
    lcd.print("A:cambiar clave");
  } else {
    lcd.print("A:clave  D:OK");
  }
}

void lcd_nueva_clave() {
  lcd.clear();
  lcd.print("Nueva clave:");
  lcd.setCursor(0, 1);
  lcd.print("(4 digitos)");
}

void lcd_confirmar_clave() {
  lcd.clear();
  lcd.print("Confirme clave:");
}

void lcd_alarma(int contAlarmas) {
  lcd.setCursor(0, 1);
  lcd.print("Alarmas: ");
  lcd.print(contAlarmas);
  lcd.print("   ");
}