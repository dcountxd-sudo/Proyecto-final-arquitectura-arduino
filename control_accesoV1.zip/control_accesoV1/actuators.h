#ifndef ACTUATORS_H
#define ACTUATORS_H

#include <Arduino.h>
#include <Servo.h>
#include "pins.h"
#include "constants.h"

void actuators_init();
void setLED(bool r, bool g, bool b);
void apagarTodo();
void parpadeoRojo(unsigned long onTime, unsigned long offTime);
void servo_abrir();
void servo_cerrar();
void buzzer_on();
void buzzer_off();
bool boton_presionado();

#endif