#ifndef EEPROM_H
#define EEPROM_H

#include <EEPROM.h>
#include "constants.h"

enum Rol { ROL_SEGURIDAD, ROL_OPERARIO, ROL_COORDINADOR, ROL_GERENTE };

struct Usuario {
  char nombre[MAX_NOMBRE];
  int  permiso[2];           // [horaInicio, horaFin]
  char clave[MAX_CLAVE];
  char historial[MAX_HISTORIAL][MAX_CLAVE];
  byte usos;
  byte uid[MAX_UID];
  Rol  perfil;
};

void eeprom_init();
void guardarUsuario(int idx, const Usuario &u);
void leerUsuario(int idx, Usuario &u);
int  buscarPorClave(const char* clave);
int  buscarPorUID(const byte* uid);
bool claveRepetida(const Usuario &u, const char* clave);
void cambiarClave(int idx, const char* nuevaClave);
bool dentroFranja(const Usuario &u, byte horaActual);

#endif