#ifndef FSM_H
#define FSM_H

#include "StateMachineLib.h"

enum State {
  INICIO            = 0,
  CONFIG            = 1,
  MONITOR_AMBIENTAL = 2,
  MONITOR_INTRUSOS  = 3,
  ALARMA            = 4,
  BLOQUEO           = 5
};

enum Input {
  INPUT_CLAVE_OK   = 0,
  INPUT_CLAVE_MAL  = 1,
  INPUT_BLOQUEADO  = 2,
  INPUT_SENSOR_MAL = 3,
  INPUT_ALARMA_AMB = 4,
  INPUT_ALARMA_INT = 5,
  INPUT_RESET      = 6,
  INPUT_TIMEOUT    = 7,
  INPUT_UNKNOWN    = 8
};

extern Input inputFSM;

void fsm_init();
void fsm_set_state(State nuevo);
void fsm_update();
void fsm_run_current_state();

#endif